﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace CustomerAndProducer
{
    public class BlockQueue<T>
    {
        public readonly int SizeLimit = 0;

        private Queue<T> _inner_queue = null;
        private ManualResetEvent _enqueue_wait = null;
        private ManualResetEvent _dequeue_wait = null;

        public BlockQueue(int sizeLimit)
        {
            this.IsShutdown = false;
            this.SizeLimit = sizeLimit;
            this._inner_queue = new Queue<T>();
            this._enqueue_wait = new ManualResetEvent(false);
            this._dequeue_wait = new ManualResetEvent(false);
        }

        public void EnQueue(T item)
        {
            if (this.IsShutdown == true) throw new InvalidCastException("Queue was shutdown. Enqueue was not allowed.");


            while (true)
            {
                lock (this._inner_queue)
                {
                    if (this._inner_queue.Count < this.SizeLimit)
                    {
                        this._inner_queue.Enqueue(item);
                        this._enqueue_wait.Reset();
                        this._dequeue_wait.Set();
                        break;
                    }
                }
                this._enqueue_wait.WaitOne();
            }
        }

        public T DeQueue()
        {
            while (true)
            {
                if (this.IsShutdown == true)
                {
                    lock (this._inner_queue) return this._inner_queue.Dequeue();
                }


                lock (this._inner_queue)
                {
                    if (this._inner_queue.Count > 0)
                    {
                        T item = this._inner_queue.Dequeue();
                        this._dequeue_wait.Reset();
                        this._enqueue_wait.Set();
                        return item;
                    }
                }
                this._dequeue_wait.WaitOne();
            }
        }


        public bool IsShutdown
        {
            get;
            private set;
        }

        public void Shutdown()
        {
            this.IsShutdown = true;
            this._dequeue_wait.Set();
        }
    }
}
