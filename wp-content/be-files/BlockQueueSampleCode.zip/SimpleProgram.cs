﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

namespace CustomerAndProducer
{
    public class SimpleProgram
    {
        public static int Main(string[] args)
        {
            Stopwatch timer = new Stopwatch();
            timer.Start();

            FileStream fs = new FileStream(Path.Combine(PhotoJob.destFolder, "result.zip"), FileMode.Create);
            ZipOutputStream zos = new ZipOutputStream(fs);

            foreach (PhotoJob job in PhotoJob.GetJobs())
            {
                job.Download();
                job.MakeThumb();
                job.AddZip(zos);
            }

            zos.Close();
            fs.Close();

            Console.WriteLine("Jobs complete. {0:0.##} sec.", timer.Elapsed.TotalSeconds);

            return 0;
        }
    }
}
