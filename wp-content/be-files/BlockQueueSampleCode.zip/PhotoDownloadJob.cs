﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.IO.Compression;
using ICSharpCode.SharpZipLib.Zip;
using System.Windows.Media.Imaging;
using System.Windows.Media;

namespace CustomerAndProducer
{
    public class PhotoJob
    {
        public const string sourceFolder = @"D:\TempDisk\BlockQueueWork\Source";
        public const string destFolder = @"D:\TempDisk\BlockQueueWork\Destination";

        /// <summary>
        /// 模擬網路下載的連線速度。單位是 kbps
        /// </summary>
        private const double Speed = 1024 * 10;

        /// <summary>
        /// 模擬同時連線下載的最大數量
        /// </summary>
        private const int MaxDownloadConnection = 3;

        /// <summary>
        /// 圖片縮放比例
        /// </summary>
        private const double Scale = 0.6D;

        private static Semaphore connlimit = new Semaphore(MaxDownloadConnection, MaxDownloadConnection);

        public PhotoJob(string sourcePath, string destPath)
        {
            this.SourcePath = sourcePath;
            this.DestPath = destPath;
            this.IsThumbReady = false;
        }
        public string SourcePath = null;
        public string DestPath = null;
        public bool IsThumbReady
        {
            get;
            private set;
        }

        /// <summary>
        /// 用 copy file + sleep() 來模擬較慢的 internet 下載檔案。sleep暫停的時間會依照檔案大小，及指定的連線速度
        /// 來決定。這個 method 的執行時間會等同於透過 internet 下載同樣大小的檔案花的時間。
        /// 
        /// 另外，這個 method 會限至同一瞬間建立的網路連線數為 MaxDownloadConnection。如果超過，則後面的執行緒會暫停。
        /// </summary>
        public void Download()
        {
            connlimit.WaitOne();
            FileInfo fi = new FileInfo(this.SourcePath);
            DateTime start = DateTime.Now;
            fi.CopyTo(this.DestPath + ".tmp", true);
            TimeSpan duration = TimeSpan.FromSeconds(fi.Length * 8 / 1024 / Speed);
            if (DateTime.Now < (start + duration))
            {
                Thread.Sleep(start + duration - DateTime.Now);
            }
            connlimit.Release();
        }

        public void MakeThumb()
        {
            BitmapDecoder source = BitmapDecoder.Create(
                new Uri(this.DestPath + ".tmp"),
                BitmapCreateOptions.None,
                BitmapCacheOption.None);
            JpegBitmapEncoder target = new JpegBitmapEncoder();
            target.Frames.Add(BitmapFrame.Create(
                new TransformedBitmap(source.Frames[0], new ScaleTransform(Scale, Scale)),
                source.Frames[0].Thumbnail,
                (source.Frames[0].Metadata as BitmapMetadata).Clone(),
                source.Frames[0].ColorContexts));
            FileStream fs = File.Open(this.DestPath, FileMode.Create);
            target.Save(fs);
            fs.Close();
            this.IsThumbReady = true;
        }

        public void AddZip(ZipOutputStream zos)
        {
            ZipEntry ze = new ZipEntry(Path.GetFileName(this.DestPath));

            zos.PutNextEntry(ze);
            byte[] buffer = File.ReadAllBytes(this.DestPath);
            zos.Write(
                buffer,
                0,
                buffer.Length);
            zos.CloseEntry();

            Thread.Sleep(1000);
        }

        public void DownloadAndMakeThumb(object state)
        {
            this.Download();
            this.MakeThumb();
        }




        public static IEnumerable<PhotoJob> GetJobs()
        {

            foreach (string path in Directory.GetFiles(sourceFolder, "*.jpg", SearchOption.TopDirectoryOnly))
            {
                PhotoJob dj = new PhotoJob(
                    path,
                    Path.Combine(destFolder, Path.GetFileName(path)));

                yield return dj;
            }

            yield break;
        }
    }
}
