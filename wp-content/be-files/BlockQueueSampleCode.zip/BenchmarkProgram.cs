﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CustomerAndProducer
{
    class BenchmarkProgram
    {
        public static int Main(string[] args)
        {

            ThreadPoolProgram.Main(args);

            PipelineProgram.Main(args);

            return 0;
        }
    }
}
