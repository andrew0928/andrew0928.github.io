﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

namespace CustomerAndProducer
{
    public class PipelineProgram
    {
        public const int ConcurrentDownloadThreads = 3;
        public const int ConcurrentMakeThumbThreads = 5;

        private static IEnumerator<PhotoJob> jobs = null;

        private static BlockQueue<PhotoJob> downloadBufferQueue = new BlockQueue<PhotoJob>(int.MaxValue);
        private static BlockQueue<PhotoJob> thumbQueue = new BlockQueue<PhotoJob>(int.MaxValue);

        public static int Main(string[] args)
        {
            Stopwatch timer = new Stopwatch();
            timer.Start();

            // 1. init
            jobs = PhotoJob.GetJobs().GetEnumerator();

            List<Thread> downloadWorkers = new List<Thread>();
            for (int t = 0; t < ConcurrentDownloadThreads; t++)
            {
                downloadWorkers.Add(new Thread(DownloadWorker));
            }

            List<Thread> resizeWorkers = new List<Thread>();
            for (int t = 0; t < ConcurrentMakeThumbThreads; t++)
            {
                resizeWorkers.Add(new Thread(MakeThumbWorker));
            }

            Thread zipWorker = new Thread(AddZipWorker);
            zipWorker.Priority = ThreadPriority.Lowest;


            foreach (Thread t in downloadWorkers)
            {
                t.Start();
            }
            foreach (Thread t in resizeWorkers)
            {
                t.Start();
            }
            zipWorker.Start();





            // 2. wait complete
            foreach (Thread t in downloadWorkers)
            {
                t.Join();
            }
            downloadBufferQueue.Shutdown();
            foreach (Thread t in resizeWorkers)
            {
                t.Join();
            }
            thumbQueue.Shutdown();
            zipWorker.Join();
            Console.WriteLine("Jobs complete. {0:0.##} sec.", timer.Elapsed.TotalSeconds);
            return 0;
        }


        private static void DownloadWorker()
        {
            do
            {
                PhotoJob dj = null;
                lock (jobs) if (jobs.MoveNext()) dj = jobs.Current;
                if (dj == null) break;
                dj.Download();
                downloadBufferQueue.EnQueue(dj);
            } while (true);
        }

        private static void MakeThumbWorker()
        {
            try
            {
                while (true)
                {
                    PhotoJob dj = downloadBufferQueue.DeQueue();
                    dj.MakeThumb();
                    thumbQueue.EnQueue(dj);
                }
            }
            catch (InvalidOperationException)
            {
            }
        }

        private static void AddZipWorker()
        {
            FileStream fs = new FileStream(Path.Combine(PhotoJob.destFolder, "result.zip"), FileMode.Create);
            ZipOutputStream zos = new ZipOutputStream(fs);

            try
            {
                while (true)
                {
                    PhotoJob dj = thumbQueue.DeQueue();
                    dj.AddZip(zos);
                }
            }
            catch (InvalidOperationException)
            {
            }

            zos.Close();
            fs.Close();
        }



    }
}
