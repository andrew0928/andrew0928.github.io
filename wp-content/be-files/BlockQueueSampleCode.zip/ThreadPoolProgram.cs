﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

namespace CustomerAndProducer
{
    public class ThreadPoolProgram
    {
        public static int Main(string[] args)
        {
            Stopwatch timer = new Stopwatch();
            timer.Start();

            List<PhotoJob> list = new List<PhotoJob>();
            foreach (PhotoJob job in PhotoJob.GetJobs())
            {
                list.Add(job);
                ThreadPool.QueueUserWorkItem(job.DownloadAndMakeThumb);
            }

            bool exit = true;
            do
            {
                Thread.Sleep(10);
                exit = true;
                foreach (PhotoJob pdj in list)
                {
                    if (pdj.IsThumbReady == true) continue;
                    exit = false;
                    break;
                }
            } while (!exit);


            {
                FileStream fs = new FileStream(Path.Combine(PhotoJob.destFolder, "result.zip"), FileMode.Create);
                ZipOutputStream zos = new ZipOutputStream(fs);

                foreach (PhotoJob pdj in list)
                {
                    pdj.AddZip(zos);
                }

                zos.Close();
                fs.Close();
            }




            Console.WriteLine("Jobs complete. {0:0.##} sec.", timer.Elapsed.TotalSeconds);

            return 0;

        }
    }
}
