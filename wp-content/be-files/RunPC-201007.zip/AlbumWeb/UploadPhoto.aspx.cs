﻿#define USE_TRANSACTION
#define USE_ALPHAFS

using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Transactions;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

public partial class UploadPhoto : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
#if (USE_TRANSACTION)
#if (USE_ALPHAFS)
        using (TransactionScope scope = new TransactionScope())
        {
            try
            {
                Alphaleonis.Win32.Filesystem.KernelTransaction ktm = new Alphaleonis.Win32.Filesystem.KernelTransaction(Transaction.Current);

                //IDtcTransaction dtc = TransactionInterop.GetDtcTransaction(Transaction.Current);
                //IKernelTransaction ktm = (IKernelTransaction)dtc;
                //IntPtr kth;
                //ktm.GetHandle(out kth);
                


                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["photoDB"].ConnectionString))
                {
                    conn.Open();
                    SqlCommand cmd = conn.CreateCommand();

                    cmd.CommandText = "insert photos (Description, ImagePath) values (@desc, @path); select NULLIF(SCOPE_IDENTITY(), 0);";

                    foreach (UploadPhotoData p in this.GetUploadPhotos())
                    {
                        string path = string.Format(
                            "{0:N}.jpg",
                            Guid.NewGuid());

                        {
                            //SafeFileHandle fh = CreateFileTransacted(
                            //    this.Server.MapPath("~/App_Data/photos/" + path),
                            //    0x40000000,
                            //    0x00000000,
                            //    IntPtr.Zero,
                            //    0x00000001,
                            //    0x00000080,
                            //    IntPtr.Zero,
                            //    kth,
                            //    IntPtr.Zero,
                            //    IntPtr.Zero);

                            Stream source = p.FileUploadControl.PostedFile.InputStream;
                            //Stream target = new FileStream(fh, FileAccess.Write);
                            Stream target = Alphaleonis.Win32.Filesystem.File.Open(
                                ktm,
                                this.Server.MapPath("~/App_Data/photos/" + path),
                                Alphaleonis.Win32.Filesystem.FileMode.Create,
                                Alphaleonis.Win32.Filesystem.FileAccess.Write);

                            byte[] buffer = new byte[4096];
                            int count = 0;

                            while ((count = source.Read(buffer, 0, buffer.Length)) > 0)
                            {
                                target.Write(buffer, 0, count);
                            }

                            source.Close();
                            target.Close();
                            this.Trace.Write(string.Format("檔案 ({0}) 上傳成功!", path));
                        }


                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("desc", p.TextBoxControl.Text);
                        cmd.Parameters.AddWithValue("path", path);
                        //cmd.Parameters.AddWithValue("path", DBNull.Value);
                        int resultPK = (int)(decimal)cmd.ExecuteScalar();
                        this.Trace.Write(string.Format("資料庫 [photos.PK: ({0}] 更新成功!", resultPK));
                    }
                }

                throw new Exception("cancel transaction");

                scope.Complete();
            }
            catch (Exception ex)
            {
                this.Trace.Warn("Exception", ex.ToString());
                this.Trace.Warn("Transaction Rollback.");

                throw;
            }
        }
#else
        using (TransactionScope scope = new TransactionScope())
        {
            try
            {

                IDtcTransaction dtc = TransactionInterop.GetDtcTransaction(Transaction.Current);
                IKernelTransaction ktm = (IKernelTransaction)dtc;
                IntPtr kth;
                ktm.GetHandle(out kth);



                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["photoDB"].ConnectionString))
                {
                    conn.Open();
                    SqlCommand cmd = conn.CreateCommand();

                    cmd.CommandText = "insert photos (Description, ImagePath) values (@desc, @path); select NULLIF(SCOPE_IDENTITY(), 0);";

                    foreach (UploadPhotoData p in this.GetUploadPhotos())
                    {
                        string path = string.Format(
                            "{0:N}.jpg",
                            Guid.NewGuid());

                        {
                            SafeFileHandle fh = CreateFileTransacted(
                                this.Server.MapPath("~/App_Data/photos/" + path),
                                0x40000000,
                                0x00000000,
                                IntPtr.Zero,
                                0x00000001,
                                0x00000080,
                                IntPtr.Zero,
                                kth,
                                IntPtr.Zero,
                                IntPtr.Zero);

                            Stream source = p.FileUploadControl.PostedFile.InputStream;
                            Stream target = new FileStream(fh, FileAccess.Write);

                            byte[] buffer = new byte[4096];
                            int count = 0;

                            while ((count = source.Read(buffer, 0, buffer.Length)) > 0)
                            {
                                target.Write(buffer, 0, count);
                            }

                            source.Close();
                            target.Close();
                            this.Trace.Write(string.Format("檔案 ({0}) 上傳成功!", path));
                        }


                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("desc", p.TextBoxControl.Text);
                        cmd.Parameters.AddWithValue("path", path);
                        //cmd.Parameters.AddWithValue("path", DBNull.Value);
                        int resultPK = (int)(decimal)cmd.ExecuteScalar();
                        this.Trace.Write(string.Format("資料庫 [photos.PK: ({0}] 更新成功!", resultPK));
                    }
                }

                throw new Exception("cancel transaction");

                scope.Complete();
            }
            catch (Exception ex)
            {
                this.Trace.Warn("Exception", ex.ToString());
                this.Trace.Warn("Transaction Rollback.");

                throw;
            }
        }
#endif


#else

        using (TransactionScope s = new TransactionScope())
        {


            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["photoDB"].ConnectionString))
            {
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();

                cmd.CommandText = "insert photos (Description, ImagePath) values (@desc, @path); select NULLIF(SCOPE_IDENTITY(), 0);";

                foreach (UploadPhotoData p in this.GetUploadPhotos())
                {
                    string path = string.Format(
                        "{0:N}.jpg",
                        Guid.NewGuid());

                    {
                        p.FileUploadControl.SaveAs(this.Server.MapPath("~/App_Data/photos/" + path));
                        this.Trace.Write(string.Format("檔案 ({0}) 上傳成功!", path));
                    }


                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("desc", p.TextBoxControl.Text);
                    cmd.Parameters.AddWithValue("path", path);
                    int resultPK = (int)(decimal)cmd.ExecuteScalar();
                    this.Trace.Write(string.Format("資料庫 [photos.PK: ({0}] 更新成功!", resultPK));
                }
            }

            throw new Exception("cancel transaction");
            s.Complete();
        }


        //using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["photoDB"].ConnectionString))
        //{
        //    conn.Open();
        //    SqlCommand cmd = conn.CreateCommand();

        //    cmd.CommandText = "insert photos (Description, ImagePath) values (@desc, @path); select NULLIF(SCOPE_IDENTITY(), 0);";

        //    foreach (UploadPhotoData p in this.GetUploadPhotos())
        //    {
        //        string path = string.Format(
        //            "~/App_Data/photos/{0:N}.jpg",
        //            Guid.NewGuid());

        //        p.FileUploadControl.SaveAs(this.Server.MapPath(path));

        //        cmd.Parameters.Clear();
        //        cmd.Parameters.AddWithValue("desc", p.TextBoxControl.Text);
        //        cmd.Parameters.AddWithValue("path", path);
        //        int resultPK = (int)(decimal)cmd.ExecuteScalar();

        //        this.Trace.Warn("P1.PK", resultPK.ToString());
        //        this.Trace.Warn("P1.Desc", p.TextBoxControl.Text);
        //        this.Trace.Warn("P1.File", p.FileUploadControl.FileName);
        //    }
        //}
#endif


        this.Response.Redirect("~/");
    }


    public IEnumerable<UploadPhotoData> GetUploadPhotos()
    {
        if (this.FileUpload1.HasFile)
        {
            yield return new UploadPhotoData()
            {
                TextBoxControl = this.TextBox1,
                FileUploadControl = this.FileUpload1
            };
        }
        if (this.FileUpload2.HasFile)
        {
            yield return new UploadPhotoData()
            {
                TextBoxControl = this.TextBox2,
                FileUploadControl = this.FileUpload2
            };
        }
        if (this.FileUpload3.HasFile)
        {
            yield return new UploadPhotoData()
            {
                TextBoxControl = this.TextBox3,
                FileUploadControl = this.FileUpload3
            };
        }
    }

    public class UploadPhotoData
    {
        public TextBox TextBoxControl;
        public FileUpload FileUploadControl;
    }






    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("79427A2B-F895-40e0-BE79-B57DC82ED231")]
    public interface IKernelTransaction
    {
        void GetHandle([Out] out IntPtr handle);
    }


    [DllImport("KERNEL32.dll", 
        EntryPoint = "CreateFileTransacted",
        CharSet = CharSet.Unicode, 
        SetLastError = true)]
    internal static extern SafeFileHandle CreateFileTransacted(
        [In] string lpFileName,
        [In] uint dwDesiredAccess,       //
        [In] uint dwShareMode,           //
        [In] IntPtr lpSecurityAttributes,
        [In] uint dwCreationDisposition, //
        [In] uint dwFlagsAndAttributes,
        [In] IntPtr hTemplateFile,
        [In] IntPtr hTransaction,
        [In] IntPtr pusMiniVersion,
        [In] IntPtr pExtendedParameter);
}