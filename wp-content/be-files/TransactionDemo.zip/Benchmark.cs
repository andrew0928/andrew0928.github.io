﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.IO;

namespace TransactionDemo
{
    public class Benchmark
    {
        [DllImport("Kernel32.dll")]
        private static extern bool DeleteFileTransactedW(
            [MarshalAs(UnmanagedType.LPWStr)]string file,
            IntPtr transaction);

        [DllImport("Kernel32.dll")]
        private static extern bool CloseHandle(IntPtr handle);

        [DllImport("Ktmw32.dll")]
        private static extern bool CommitTransaction(IntPtr transaction);

        [DllImport("Ktmw32.dll")]
        private static extern bool RollbackTransaction(IntPtr transaction);

        [DllImport("Ktmw32.dll")]
        private static extern IntPtr CreateTransaction(
            IntPtr securityAttributes,
            IntPtr guid,
            int options,
            int isolationLevel,
            int isolationFlags,
            int milliSeconds,
            string description);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        private static extern bool CopyFileTransacted(
            string lpExistingFileName, 
            string lpNewFileName, 
            IntPtr lpProgressRoutine, 
            IntPtr lpData, 
            ref bool pbCancel, 
            int dwCopyFlags, 
            IntPtr transaction);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        private static extern bool CopyFile(
            string lpExistingFileName, 
            string lpNewFileName, 
            bool bFailIfExists);

        private const int MAX_COUNT = 100;


        public static void Main(string[] args)
        {
            Stopwatch timer = new Stopwatch();


            for (int maxcount = 10; maxcount <= 100; maxcount += 10)
            {
                long normalElaspedMsec = 0;
                long transactedElaspedMsec = 0;
                long transactedTotalElaspedMsec = 0;

                if (Directory.Exists(@"E:\Temp\TXF") == true) Directory.Delete(@"E:\Temp\TXF", true);
                Directory.CreateDirectory(@"E:\Temp\TXF");

                timer.Reset();
                timer.Start();
                {
                    CopyFiles(maxcount);
                }
                normalElaspedMsec = timer.ElapsedMilliseconds;
                //Console.WriteLine("Basic File I/O: {0} msec.", timer.ElapsedMilliseconds);



                if (Directory.Exists(@"E:\Temp\TXF") == true) Directory.Delete(@"E:\Temp\TXF", true);
                Directory.CreateDirectory(@"E:\Temp\TXF");
                timer.Reset();
                timer.Start();
                {
                    IntPtr transaction = CreateTransaction(
                        IntPtr.Zero,
                        IntPtr.Zero,
                        0, 0, 0, 0,
                        null);
                    CopyFilesTransacted(maxcount, transaction);
                    transactedElaspedMsec = timer.ElapsedMilliseconds;

                    //CommitTransaction(transaction);
                    RollbackTransaction(transaction);
                    transactedTotalElaspedMsec = timer.ElapsedMilliseconds;
                    
                    CloseHandle(transaction);
                    //Console.WriteLine("TxF(transaction complete): {0} msec.", timer.ElapsedMilliseconds);
                }

                Console.WriteLine(
                    "重複次數: {0},\t複製時間(非交易): {1}ms,\t複製時間(交易): {2}ms({4}%),\t複製+回復(交易): {3}ms({5}%)",
                    maxcount,
                    normalElaspedMsec,
                    transactedElaspedMsec,
                    transactedTotalElaspedMsec,
                    transactedElaspedMsec * 100 / normalElaspedMsec,
                    transactedTotalElaspedMsec * 100 / normalElaspedMsec);

            }


        }




        public static void CopyFilesTransacted(int maxcount, IntPtr transaction)
        {
            bool dummy = false;
            for (int count = 1; count <= maxcount; count++)
            {
                CopyFileTransacted(
                    @"C:\SamplePicture.jpg",
                    string.Format(@"E:\Temp\TXF\FILE-{0:D05}.jpg", count),
                    IntPtr.Zero,
                    IntPtr.Zero,
                    ref dummy,
                    0,
                    transaction);
            }
        }

        public static void CopyFiles(int maxcount)
        {
            for (int count = 1; count <= maxcount; count++)
            {
                CopyFile(
                    @"C:\SamplePicture.jpg",
                    string.Format(@"E:\Temp\TXF\FILE-{0:D05}.jpg", count),
                    false);
            }
        }
    }
}
