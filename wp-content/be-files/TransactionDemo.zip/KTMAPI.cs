﻿using System;
using System.Runtime.InteropServices;
using System.IO;

namespace TransactionDemo
{
    public class KTMAPI
    {
        [DllImport("Kernel32.dll")]
        private static extern bool DeleteFileTransactedW(
            [MarshalAs(UnmanagedType.LPWStr)]string file, 
            IntPtr transaction);

        [DllImport("Kernel32.dll")]
        private static extern bool CloseHandle(IntPtr handle);

        [DllImport("Ktmw32.dll")]
        private static extern bool CommitTransaction(IntPtr transaction);

        [DllImport("Ktmw32.dll")]
        private static extern bool RollbackTransaction(IntPtr transaction);

        [DllImport("Ktmw32.dll")]
        private static extern IntPtr CreateTransaction(
            IntPtr securityAttributes, 
            IntPtr guid, 
            int options, 
            int isolationLevel, 
            int isolationFlags, 
            int milliSeconds, 
            string description);


        /*

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetFileInformationByHandle(
            IntPtr hFile, 
            out BY_HANDLE_FILE_INFORMATION lpFileInformation);

        struct BY_HANDLE_FILE_INFORMATION
        {
            public uint FileAttributes;
            public FILETIME CreationTime;
            public FILETIME LastAccessTime;
            public FILETIME LastWriteTime;
            public uint VolumeSerialNumber;
            public uint FileSizeHigh;
            public uint FileSizeLow;
            public uint NumberOfLinks;
            public uint FileIndexHigh;
            public uint FileIndexLow;
        }

        */


        public static void CheckFiles(string[] files)
        {
            Console.WriteLine();
            Console.WriteLine("確認檔案是否存在?");
            foreach (string file in files)
            {
                Console.WriteLine(
                    "   - 檔案({0}): {1}",
                    file,
                    File.Exists(file) ? "存在" : "不存在");
            }
            Console.WriteLine();
        }

        
        public static void Main(string[] args)
        {
            // 建立 KTM transaction object
            IntPtr transaction = CreateTransaction(
                IntPtr.Zero,
                IntPtr.Zero,
                0, 0, 0, 0,
                null);

            string[] files = new string[] {
                @"c:\file1.txt",
                @"c:\file2.txt",
                @"c:\file3.txt"};



            CheckFiles(files);
            try
            {
                foreach (string file in files)
                {
                    Console.Write("刪除檔案({0}): ", file);
                    // 使用支援交易的 delete file API
                    if (DeleteFileTransactedW(file, transaction) == true)
                    {
                        Console.WriteLine("刪除成功");
                    }
                    else
                    {
                        Console.WriteLine("刪除失敗");
                        throw new InvalidOperationException();
                    }
                }

                //CheckFiles(files);

                // 認可交易
                Console.WriteLine("按下 [ENTER] 之後，認可交易...");
                Console.ReadLine();
                CommitTransaction(transaction);
            }
            catch (Exception ex)
            {
                // 還原交易
                Console.WriteLine("還原交易:\nException: {0}", ex);
                RollbackTransaction(transaction);
            }
            CloseHandle(transaction);
            CheckFiles(files);

            
        }
    }
}