﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace StartApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string location = Path.GetTempFileName() + ".jpg";
            FileStream target = File.OpenWrite(location);
            Stream source = this.GetType().Assembly.GetManifestResourceStream("attachment");

            int count = 0;
            byte[] buffer = new byte[4096];

            while ((count = source.Read(buffer, 0, buffer.Length)) > 0)
            {
                target.Write(buffer, 0, count);
            }

            target.Close();
            source.Close();



            Process p = Process.Start(location);
            p.WaitForExit();

            File.Delete(location);
            this.Close();
        }
    }
}