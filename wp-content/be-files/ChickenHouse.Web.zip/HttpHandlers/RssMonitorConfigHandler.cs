using System;
using System.Xml;

namespace ChickenHouse.Web.HttpHandlers
{
	/// <summary>
	/// Summary description for RssMonitorConfigHandler.
	/// </summary>
	public class RssMonitorConfigHandler : System.Configuration.IConfigurationSectionHandler
	{
		#region IConfigurationSectionHandler Members

		public object Create(object parent, object configContext, System.Xml.XmlNode section) {
			return new RssMonitorConfig(section as XmlElement);
		}

		#endregion
	}
}
