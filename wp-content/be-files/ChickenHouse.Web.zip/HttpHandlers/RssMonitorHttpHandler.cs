using System;
using System.Collections;
using System.IO;
using System.Web;
using System.Xml;


namespace ChickenHouse.Web.HttpHandlers
{
	/// <summary>
	/// Summary description for RssMonitorHttpHandler.
	/// </summary>
	public class RssMonitorHttpHandler : IHttpHandler {
		#region IHttpHandler Members

		public void ProcessRequest(HttpContext context) {
			context.Response.ContentType = "text/xml";
			XmlWriter writer = new XmlTextWriter(context.Response.Output);
			writer.WriteStartDocument();
			writer.WriteStartElement("rss");
			writer.WriteAttributeString("version", "2.0");
			writer.WriteStartElement("channel");
			writer.WriteElementString("title", this.WebSite.Title);
			writer.WriteElementString("link", new Uri(context.Request.Url, this.WebSite.VirtualPath).ToString());
			writer.WriteElementString("description", this.WebSite.Description);
			writer.WriteElementString("language", "zh-TW");
			writer.WriteElementString("ttl", "3600");
			

			string localroot = context.Server.MapPath(this.WebSite.VirtualPath);
			foreach (string path in this.GetPagesVirtualPath(null)) {
				Uri pageURL = new Uri(context.Request.Url, this.WebSite.VirtualPath + path.Substring(localroot.Length));
				FileInfo pageFI = new FileInfo(path);

				writer.WriteStartElement("item");
				writer.WriteElementString("title", pageURL.PathAndQuery);
				writer.WriteElementString("pubDate", pageFI.LastWriteTimeUtc.ToString("r"));
				writer.WriteElementString("link", pageURL.ToString());
				writer.WriteEndElement();
			}

			writer.WriteEndElement();
			writer.WriteEndElement();
			writer.WriteEndDocument();
			writer.Flush();
			writer.Close();
		}

		public bool IsReusable {
			get {
				// TODO:  Add RssMonitorHttpHandler.IsReusable getter implementation
				return false;
			}
		}

		#endregion

	
		private RssMonitorConfig.WebSiteConfig _website = null;
		public RssMonitorConfig.WebSiteConfig WebSite {
			get {
				if (this._website == null) {
					string sReqURL = HttpContext.Current.Request.Path;
					string sAppURL = HttpContext.Current.Request.ApplicationPath;

					int startPos = (sAppURL == "/")?(1):(sAppURL.Length + 1);
					int nameLen = sReqURL.Length - startPos - 4;

					string rssName = sReqURL.Substring(startPos, nameLen);

					this._website = RssMonitorConfig.Current[rssName];
				}

				return this._website;
			}
		}


		public string[] GetPagesVirtualPath(string start) {
			ArrayList pages = new ArrayList();
			bool isFirstTime = (start == null);

			if (isFirstTime == true) {
				start = HttpContext.Current.Server.MapPath(this.WebSite.VirtualPath);

				foreach (string pattern in this.WebSite.MatchNonRecursivePatterns) {
					pages.AddRange(Directory.GetFiles(start, pattern));
				}
			}

			foreach (string pattern in this.WebSite.MatchRecursivePatterns) {
				pages.AddRange(Directory.GetFiles(start, pattern));
			}

			foreach (string folder in Directory.GetDirectories(start)) {
				pages.AddRange(this.GetPagesVirtualPath(folder));
			}

			if (isFirstTime == true) {
				ArrayList temp = new ArrayList();

				foreach (string file in pages) {
					if (temp.Contains(file) == false) {
						temp.Add(file);
					}
				}

				temp.Sort();

				pages.Clear();
				pages = temp;
			}

			return (string[])pages.ToArray(typeof(string));
		}
		
	}
}
