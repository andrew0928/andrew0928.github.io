using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Web;
using System.Xml;
using System.Xml.Xsl;

using ICSharpCode.SharpZipLib.Zip;

namespace ChickenHouse.Web.HttpHandlers
{
	/// <summary>
	/// Summary description for ZipVirtualFolderHttpHandler.
	/// </summary>
	public class ZipVirtualFolderHttpHandler : IHttpHandler {
		#region IHttpHandler Members

		public void ProcessRequest(HttpContext context) {
			
			if (context.Request.PathInfo.Length == 0) {
				//
				//	no extra path info
				//
				if (context.Request.Url.Query.Length == 0 || context.Request.Url.Query.ToLower() == "?list") {
					//
					//	without any query string, show folder list.
					//
					XmlDocument zipDoc = this.GetZipDocument(context);

					context.Response.ContentType = "text/html";
					ZipVirtualFolderBrowseXSLT.Transform(
						zipDoc,
						null,
						context.Response.Output);
				} else if (context.Request.Url.Query.ToLower() == "?xml") {
					//
					//	show zip manifest xml document
					//
					context.Response.ContentType = "text/xml";
					this.GetZipDocument(context).Save(context.Response.Output);
				} else if (context.Request.Url.Query.ToLower() == "?download") {
					//
					//	download zip directly. 
					//
					context.Response.ContentType = this.GetMimeType(".zip");
					//context.Response.WriteFile(context.Request.PhysicalPath);
					context.Response.TransmitFile(context.Request.PhysicalPath);
				}
			} else {
				//
				//	contain extra path info, ignore query string
				//

				//
				//	mapping zip file as virtual folder.
				//
				ZipFile zf = new ZipFile(context.Request.PhysicalPath);
				int index = zf.FindEntry(context.Server.UrlDecode(context.Request.PathInfo.Substring(1)), true);
				Stream input = zf.GetInputStream(index);
				string extension = context.Request.PathInfo.Substring(context.Request.PathInfo.LastIndexOf("."));
				string extensionContentType = this.GetMimeType(extension);


				if (extensionContentType.StartsWith("image/", StringComparison.OrdinalIgnoreCase) && context.Request.RawUrl.EndsWith("?thumb"))
				{
					//
					//	�p�G URL ��: ...../foo.zip/..../foo.jpg?thumb, �h��X�Y��
					//
					context.Response.ContentType = "image/jpeg";

					string cacheKey = string.Format(
						"thumb.cache${0}${1}", 
						context.Request.PhysicalPath.ToLower(), 
						context.Request.PathInfo.Substring(1).ToLower());

					Image trgImage = context.Cache[cacheKey] as Image;

					if (trgImage == null)
					{
						//
						//	resource file is image, and show as thumbnail
						//
						Image srcImage = Image.FromStream(input);
						trgImage = new Bitmap(srcImage, this.ComputeThumbSize(srcImage.Size, new Size(64, 64)));

						//
						//	update cache
						//
						context.Cache.Insert(
							cacheKey,
							trgImage,
							new System.Web.Caching.CacheDependency(context.Request.PhysicalPath),
							System.Web.Caching.Cache.NoAbsoluteExpiration,
							new TimeSpan(0, 20, 0),
							System.Web.Caching.CacheItemPriority.Low,
							null);
					}

					trgImage.Save(
						context.Response.OutputStream,
						ImageFormat.Jpeg);
				}
				else if (context.Request.PathInfo.EndsWith(".asf", StringComparison.OrdinalIgnoreCase) || context.Request.PathInfo.EndsWith(".wma", StringComparison.OrdinalIgnoreCase) || context.Request.PathInfo.EndsWith(".wmv", StringComparison.OrdinalIgnoreCase)) //if (context.Request.UserAgent.StartsWith("NSPlayer/") || context.Request.UserAgent.StartsWith("Windows-Media-Player/"))
				{
					//
					//	�p�G���w�ɮ׬� windows media file, �h�ಾ�� media service
					//

					//
					//	step 1. deploy
					//
					System.Collections.Specialized.NameValueCollection mediaConfig = System.Configuration.ConfigurationSettings.GetConfig("website.media.filter") as System.Collections.Specialized.NameValueCollection;

					FileInfo zipInfo = new FileInfo(context.Request.PhysicalPath);
					string cacheKey = string.Format(
						"{0:D20}.{1:D10}.{2}.{3}",
						zipInfo.LastWriteTime.Ticks,
						zipInfo.Length,
						zipInfo.Name,
						context.Request.PathInfo.Replace('/', '$'));
					string deployLocation = mediaConfig["media.service.path"] + cacheKey;

					if (File.Exists(deployLocation) == false)
					{
						byte[] buffer = new byte[4096];
						int count = 0;
						FileStream fs = File.OpenWrite(deployLocation);

						while ((count = input.Read(buffer, 0, buffer.Length)) > 0)
						{
							fs.Write(buffer, 0, count);
						}

						zf.Close();
						fs.Close();
					}

					//
					//	step 2. redirect
					//
					//
					//	step 2. generate asx file content
					//
					string mediaMetaCacheKey = "resource$HttpHandlers.MedaServiceMeta.xml";
					XmlDocument metaDoc = context.Cache[mediaMetaCacheKey] as XmlDocument;

					if (metaDoc == null)
					{
						Stream s = this.GetType().Assembly.GetManifestResourceStream(this.GetType(), "MediaServiceMeta.xml");
						metaDoc = new XmlDocument();

						metaDoc.Load(s);
						s.Close();

						context.Cache.Insert(
							mediaMetaCacheKey,
							metaDoc,
							null,
							System.Web.Caching.Cache.NoAbsoluteExpiration,
							System.Web.Caching.Cache.NoSlidingExpiration,
							System.Web.Caching.CacheItemPriority.NotRemovable,
							null);
					}

					metaDoc = metaDoc.Clone() as XmlDocument;





					metaDoc.SelectSingleNode("/ASX/ENTRY/REF/@HREF").InnerText = mediaConfig["media.service.URL"] + cacheKey;

					context.Response.ContentType = "video/x-ms-asf";
					context.Response.Output.Write(metaDoc.DocumentElement.OuterXml);
				} 
				else
				{
					context.Response.ContentType = extensionContentType;

					byte[] buffer = new byte[4096];
					int count = 0;

					while ((count = input.Read(buffer, 0, buffer.Length)) > 0)
					{
						context.Response.OutputStream.Write(buffer, 0, count);
					}

					zf.Close();
				}
			}
		}

		public bool IsReusable {
			get {
				return true;
			}
		}

		#endregion


		public XmlDocument GetZipDocument(HttpContext context) {
			string cacheKey = string.Format("zipdoc${0}", context.Request.PhysicalPath.ToLower());
			XmlDocument zipDoc = context.Cache[cacheKey] as XmlDocument;

			if (zipDoc == null)
			{
				//
				//	listing zip manifest.
				//
				FileInfo fi = new FileInfo(context.Request.PhysicalPath);
				ZipFile zf = new ZipFile(context.Request.PhysicalPath);
				zipDoc = new XmlDocument();

				zipDoc.LoadXml("<?xml version=\"1.0\" ?><zip />");
				zipDoc.DocumentElement.SetAttribute("vdir", context.Request.FilePath);
				zipDoc.DocumentElement.SetAttribute("name", zf.Name);
                //zipDoc.DocumentElement.SetAttribute("url", context.Server.UrlPathEncode(zf.Name));
				zipDoc.DocumentElement.SetAttribute("size", fi.Length.ToString());
				zipDoc.DocumentElement.SetAttribute("datetime", fi.LastWriteTime.ToString());
				zipDoc.DocumentElement.SetAttribute("comment", zf.ZipFileComment);

				foreach (ZipEntry ze in zf)
				{
					if (ze.IsDirectory == true) continue;

					XmlElement elem = zipDoc.CreateElement("entry");

					elem.SetAttribute("name", ze.Name);
                    elem.SetAttribute("url", context.Server.UrlPathEncode(ze.Name.Replace("#", context.Server.UrlEncode("#"))));
					elem.SetAttribute("commente", ze.Comment);
					elem.SetAttribute("compressedSize", ze.CompressedSize.ToString());
					elem.SetAttribute("size", ze.Size.ToString());
					elem.SetAttribute("method", ze.CompressionMethod.ToString());
					elem.SetAttribute("percent", (ze.CompressedSize * 100 / ze.Size).ToString());
					elem.SetAttribute("datetime", ze.DateTime.ToString());

					int extPos = ze.Name.LastIndexOf('.');
					string extension = (extPos >= 0) ? (ze.Name.Substring(extPos)) : (null);

					elem.SetAttribute("content-type", this.GetMimeType(extension));
					if (ze.Name.LastIndexOf('.') > 0)
					{
					}

					zipDoc.DocumentElement.AppendChild(elem);
				}
				zf.Close();



				//
				//	update cache
				//
				context.Cache.Insert(
					cacheKey,
					zipDoc,
					new System.Web.Caching.CacheDependency(context.Request.PhysicalPath),
					System.Web.Caching.Cache.NoAbsoluteExpiration, 
					new TimeSpan(0, 20, 0), 
					System.Web.Caching.CacheItemPriority.High,
					null);
			}


			return zipDoc;
		}
	
	
		public string GetMimeType(string extension) {
			System.Collections.Specialized.NameValueCollection MimeTypeConfig = System.Configuration.ConfigurationSettings.GetConfig("website.mimetype.mapping") as System.Collections.Specialized.NameValueCollection;
			string mimetype = null;

			if (mimetype == null && extension == null) {
				mimetype = MimeTypeConfig["*"];
			}

			if (mimetype == null) {
				mimetype = MimeTypeConfig[extension.ToLower()];
			}

			if (mimetype == null) {
				mimetype = MimeTypeConfig["*"];
			}

			return mimetype;
		}


		//private static XslCompiledTransform _zipxslt = null;
		public static XslCompiledTransform ZipVirtualFolderBrowseXSLT
		{
			get {
				string cacheKey = "xslt$zipxslt";
				XslCompiledTransform _zipxslt = (XslCompiledTransform)HttpContext.Current.Cache[cacheKey];

				if (_zipxslt == null)
				{
					_zipxslt = new XslCompiledTransform();

					Stream xsltsrc = typeof(ZipVirtualFolderHttpHandler).Assembly.GetManifestResourceStream(typeof(ZipVirtualFolderHttpHandler), "ZipVirtualFolderBrowseTemplate.xslt");
					XmlReader xr = new XmlTextReader(xsltsrc);

					_zipxslt.Load(xr, null, null);

					xr.Close();
					xsltsrc.Close();

					HttpContext.Current.Cache[cacheKey] = _zipxslt;
				}

				return _zipxslt;
			}
		}



		private Size ComputeThumbSize(Size originSize, Size frameSize)
		{
            if (originSize.Width <= frameSize.Width && originSize.Height <= frameSize.Height)
            {
                //
                //  ��Ϥ��ݸg�L�Y�p�N�i�H�����ǤJ�خؤj�p, �����Y��
                //
                return originSize;
            }
            else if (originSize.Width <= frameSize.Width && originSize.Height >= frameSize.Height)
            {
                //
                //  ��ϼe�רS���W�X, ���O���צ�. �H���ת��Y�p��Ҭ���
                //
                return new Size(
                    (int)(1.0d * originSize.Width * frameSize.Height / originSize.Height),
                    frameSize.Height);
            }
            else if (originSize.Width >= frameSize.Width && originSize.Height <= frameSize.Height)
            {
                //
                //  ��ϰ��רS���W�X, ���O�e�צ�. �H�e�ת��Y�p��Ҭ���
                //
                return new Size(
                    frameSize.Width,
                    (int)(1.0d * originSize.Height * frameSize.Width / originSize.Width));
            }
            else
            {
                //
                //  ��ϰ��� & �e�׳���خؤj, �H�Y�p��Ҹ��j������
                //
                double ratioX = (double)originSize.Width / (double)frameSize.Width;
                double ratioY = (double)originSize.Height / (double)frameSize.Height;

                if (ratioX < ratioY)
                {
                    return new Size(
                        frameSize.Width,
                        (int)(originSize.Height / ratioX));
                }
                else
                {
                    return new Size(
                        (int)(originSize.Width / ratioY),
                        frameSize.Height);
                }
            }


		}
	}
}
