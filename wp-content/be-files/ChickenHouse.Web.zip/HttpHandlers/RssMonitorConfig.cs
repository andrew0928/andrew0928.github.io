using System;
using System.Collections;
using System.Xml;

namespace ChickenHouse.Web.HttpHandlers
{
	/// <summary>
	/// Summary description for RssMonitorConfig.
	/// </summary>
	public class RssMonitorConfig
	{
		private XmlElement Section = null;

		public RssMonitorConfig(XmlElement section) {
			this.Section = section;
		}


		public WebSiteConfig this[string name] {
			get {
				return new WebSiteConfig(this, name);
			}
		}

		



		public static RssMonitorConfig Current {
			get {
				return System.Configuration.ConfigurationSettings.GetConfig("website.monitor") as RssMonitorConfig;
			}
		}


		public class WebSiteConfig {
			private RssMonitorConfig ParentConfig = null;
			public readonly string Name = null;

			public WebSiteConfig(RssMonitorConfig parent, string name) {
				this.Name = name;
				this.ParentConfig = parent;

				if (this.SiteSection == null) {
					throw new ArgumentException();
				}
			}

			private XmlElement SiteSection {
				get {
					string xpath = string.Format("site[@name='{0}']", this.Name);
					return this.ParentConfig.Section.SelectSingleNode(xpath) as XmlElement;
				}
			}

			public string VirtualPath {
				get {
					return this.SiteSection.GetAttribute("virtual");
				}
			}

			public string Title {
				get {
					return this.SiteSection.GetAttribute("title");
				}
			}

			public string Description {
				get {
					if (this.SiteSection["description"] == null) {
						return null;
					} else {
						return this.SiteSection["description"].InnerText;
					}
				}
			}

			public string[] MatchRecursivePatterns {
				get {
					ArrayList pats = new ArrayList();

					foreach (XmlElement elem in this.SiteSection.SelectNodes("match[@pattern][not(@recursive)]")) {
						pats.Add(elem.GetAttribute("pattern"));
					}
					foreach (XmlElement elem in this.SiteSection.SelectNodes("match[@pattern][@recursive='true']")) {
						pats.Add(elem.GetAttribute("pattern"));
					}

					return (string[])pats.ToArray(typeof(string));
				}
			}

			public string[] MatchNonRecursivePatterns {
				get {
					ArrayList pats = new ArrayList();

					foreach (XmlElement elem in this.SiteSection.SelectNodes("match[@pattern][@recursive='false']")) {
						pats.Add(elem.GetAttribute("pattern"));
					}

					return (string[])pats.ToArray(typeof(string));
				}
			}

		}
	}
}
