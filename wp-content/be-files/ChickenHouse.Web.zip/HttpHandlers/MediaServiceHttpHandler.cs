using System;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Xml;


namespace ChickenHouse.Web.HttpHandlers {

	public class MediaServiceHttpHandler : System.Web.IHttpHandler {
		public void ProcessRequest(System.Web.HttpContext context) {
			string relativePath = context.Request.FilePath.Substring(context.Request.ApplicationPath.Length + 1);
			string physicalPath = context.Request.PhysicalPath;

			Uri serviceBaseURL = new Uri(this.CurrentConfig["media.service.URL"]);
			Uri serviceBasePath = new Uri(this.CurrentConfig["media.service.path"]);


			Version mediaPlayerVersion = new Version(this.CurrentConfig["media.player.version.default"]);
			Version requiredMediaPlayerVersion = new Version(this.CurrentConfig["media.player.version.required"]);

			if (context.Request.UserAgent == null) {
				//
				//	no user-agent header. not microsoft media player
				//
			} else if (context.Request.UserAgent.StartsWith("NSPlayer/") || context.Request.UserAgent.StartsWith("Windows-Media-Player/")) {
				//
				//	media player
				//
				int startPos = context.Request.UserAgent.IndexOf('/') + 1;
				int endPos = context.Request.UserAgent.IndexOf(' ');
				string versionText = (endPos == -1)?(context.Request.UserAgent.Substring(startPos)):(context.Request.UserAgent.Substring(startPos, endPos - startPos));
				mediaPlayerVersion = new Version(versionText);
			}




			//
			//	step 0. test media player version
			//
			if (mediaPlayerVersion < requiredMediaPlayerVersion) {
				//
				//	media player version < 7.0, do not redirect.
				//
				byte[] buffer = new byte[int.Parse(this.CurrentConfig["buffer.size"])];
				int count = 0;

				FileStream fs = File.OpenRead(physicalPath);

				context.Response.ContentType = "video/x-ms-asf";
				while ((count = fs.Read(buffer, 0, buffer.Length)) > 0) {
					context.Response.OutputStream.Write(buffer, 0, count);
				}

				fs.Close();
			} else {

				//
				//	step 1. move wmv file to temp folder
				//
				FileInfo mediaInfo = new FileInfo(physicalPath);

				string filePath = string.Format(
					"{0:D20}.{1:D10}.{2}",
					mediaInfo.LastWriteTime.Ticks,
					mediaInfo.Length,
					mediaInfo.Name);
				
				string fileFullPath = new Uri(serviceBasePath, filePath, true).LocalPath;
				if (File.Exists(fileFullPath) == false) {
					File.Copy(physicalPath, fileFullPath);
				}

				//
				//	step 2. generate asx file content
				//
				string mediaMetaCacheKey = "resource$HttpHandlers.MedaServiceMeta.xml";
				XmlDocument metaDoc = context.Cache[mediaMetaCacheKey] as XmlDocument;

				if (metaDoc == null)
				{
					Stream s = this.GetType().Assembly.GetManifestResourceStream(this.GetType(), "MediaServiceMeta.xml");
					metaDoc = new XmlDocument();

					metaDoc.Load(s);
					s.Close();

					context.Cache.Insert(
						mediaMetaCacheKey,
						metaDoc,
						null,
						System.Web.Caching.Cache.NoAbsoluteExpiration,
						System.Web.Caching.Cache.NoSlidingExpiration,
						System.Web.Caching.CacheItemPriority.NotRemovable,
						null);
				}

				metaDoc = metaDoc.Clone() as XmlDocument;





				metaDoc.SelectSingleNode("/ASX/ENTRY/REF/@HREF").InnerText = new Uri(serviceBaseURL, filePath, true).ToString();

				context.Response.ContentType = "video/x-ms-asf";
				context.Response.Output.Write(metaDoc.DocumentElement.OuterXml);
			}
		}

		public bool IsReusable {
			get {
				return true;
			}
		}



		public System.Collections.Specialized.NameValueCollection CurrentConfig {
			get {
				return System.Configuration.ConfigurationSettings.GetConfig("website.media.filter") as System.Collections.Specialized.NameValueCollection;
			}
		}

	}
}
