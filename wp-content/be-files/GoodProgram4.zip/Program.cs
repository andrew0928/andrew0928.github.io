﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace GoodProgram4
{
    public class Program
    {
        public static void Main(string[] args)
        {
            XmlDocument quizDoc = new XmlDocument();
            quizDoc.Load("quiz.xml");

            XmlDocument paperDoc = new XmlDocument();
            paperDoc.Load("paper-native.xml");

            QuizHelper qh = new BasicQuizHelper(quizDoc);
            Console.WriteLine("Final Score: {0}", qh.ComputeScore(paperDoc));
        }




    }
}
