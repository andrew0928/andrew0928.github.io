﻿using System;
using System.Data;
using System.Web;
using System.Xml;

namespace GoodProgram4

{
    public class SafeQuizHelper : QuizHelper
    {
        private QuizHelper qh1 = null;
        private QuizHelper qh2 = null;

        public SafeQuizHelper(XmlDocument quizDoc)
            : base(quizDoc)
        {
            this.qh1 = new BasicQuizHelper(quizDoc);
            this.qh2 = new XorQuizHelper(quizDoc);
        }

        public override int ComputeScore(XmlDocument paperDoc)
        {
            int score1 = this.qh1.ComputeScore(paperDoc);
            int score2 = this.qh2.ComputeScore(paperDoc);

            if (score1 != score2)
            {
                //
                //  do log
                //
                throw new InvalidProgramException("成績計算錯誤. 請參考記錄檔");
            }


            return score1;
        }
    }
}