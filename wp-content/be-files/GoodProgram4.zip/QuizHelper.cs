﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Xml;

namespace GoodProgram4
{
    /// <summary>
    /// Summary description for QuizHelper
    /// </summary>
    public abstract class QuizHelper
    {
        public static QuizHelper Create(XmlDocument quizDoc)
        {
            //return null;
            //return new BasicQuizHelper(quizDoc);
            //return new XorQuizHelper(quizDoc);
            return new SafeQuizHelper(quizDoc);
        }

        public QuizHelper(XmlDocument quizDoc)
        {
        }

        public abstract int ComputeScore(XmlDocument paperDoc);
    }
}
















