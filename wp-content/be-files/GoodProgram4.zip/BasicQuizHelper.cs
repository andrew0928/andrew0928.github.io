﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Xml;
using System.Diagnostics;


namespace GoodProgram4
{
    public class BasicQuizHelper : QuizHelper
    {
        private XmlDocument quizDoc = null;
        private int questionCount = 0;

        public BasicQuizHelper(XmlDocument quizDoc) : base(quizDoc)
        {
            this.quizDoc = quizDoc;
            this.questionCount = this.quizDoc.SelectNodes("/quiz/question").Count;
        }

        public override int ComputeScore(XmlDocument paperDoc)
        {
            //int totalScore = 0;

            //for (int questionPos = 0; questionPos < questionCount; questionPos++)
            //{
            //    XmlElement quiz_question = quizDoc.SelectNodes("/quiz/question")[questionPos] as XmlElement;
            //    XmlElement paper_question = paperDoc.SelectNodes("/quiz/question")[questionPos] as XmlElement;
            //    totalScore += ComputeQuestionScore(quiz_question, paper_question);
            //}

            //return Math.Max(0, totalScore);

            return ComputeQuizScore(this.quizDoc, paperDoc);
        }


        public static int ComputeQuizScore(XmlDocument quizDoc, XmlDocument paperDoc)
        {
            Trace.Assert(quizDoc != null);
            Trace.Assert(paperDoc != null);
            Trace.Assert(quizDoc.SelectNodes("/quiz/question").Count == paperDoc.SelectNodes("/quiz/question").Count);

            int questionCount = quizDoc.SelectNodes("/quiz/question").Count;
            int totalScore = 0;

            for (int questionPos = 0; questionPos < questionCount; questionPos++)
            {
                XmlElement quiz_question = quizDoc.SelectNodes("/quiz/question")[questionPos] as XmlElement;
                XmlElement paper_question = paperDoc.SelectNodes("/quiz/question")[questionPos] as XmlElement;
                totalScore += ComputeQuestionScore(quiz_question, paper_question);
            }

            //totalScore = Math.Max(0, totalScore);
            Trace.Assert(totalScore >= 0);
            return totalScore;
        }

        public static int ComputeQuestionScore(XmlElement quiz_question, XmlElement paper_question)
        {
            int totalScore = 0;
            int itemCount = quiz_question.SelectNodes("item").Count;

            //if (quiz_question == null)
            //{
            //    throw new Exception("沒有題目卷");
            //}
            //if (paper_question == null)
            //{
            //    throw new Exception("沒有答案卷");
            //}
            ////
            ////  確認題目跟答案的選項數目一致
            ////
            //if (paper_question.SelectNodes("item").Count != quiz_question.SelectNodes("item").Count)
            //{
            //    throw new Exception("此題的選項跟題目定義不符合");
            //}
            Trace.Assert(quiz_question != null);
            Trace.Assert(paper_question != null);
            Trace.Assert(paper_question.SelectNodes("item").Count == quiz_question.SelectNodes("item").Count);


            //
            //  如果都沒作答, 此題放棄
            //
            if (paper_question.SelectNodes("item[@checked='true']").Count == 0)
            {
                //Console.WriteLine("偵測到沒作答的答案，此題放棄");
                Trace.WriteLine("偵測到沒作答的答案，此題放棄");
                return 0;
            }



            //
            //  題目的配分
            //
            int quiz_score = int.Parse(quiz_question.GetAttribute("score"));

            //
            //  答對一個選項的分數
            //
            int item_score = quiz_score / itemCount;

            for (int itemPos = 0; itemPos < itemCount; itemPos++)
            {
                XmlElement quiz_item = quiz_question.SelectNodes("item")[itemPos] as XmlElement;
                XmlElement paper_item = paper_question.SelectNodes("item")[itemPos] as XmlElement;

                //
                //  算成積
                //
                if (quiz_item.GetAttribute("correct") == paper_item.GetAttribute("checked"))
                {
                    totalScore += item_score;
                }
                else
                {
                    totalScore -= item_score;
                }
            }

            Trace.Assert(totalScore >= (0 - quiz_score));
            Trace.Assert(totalScore <= quiz_score);
            
            return totalScore;
        }
    }
}