﻿using System;
using System.Configuration;
using System.Xml;
using System.Collections.Generic;
using System.Diagnostics;

namespace GoodProgram4

{
    public class XorQuizHelper : QuizHelper
    {
        private class QuestionInfo
        {
            public int itemScore = 0;
            public int itemBits = 0x0000;

            public int[] correctItemCountTable = new int[] {
                4 - 0 * 2,  // 0000
                4 - 1 * 2,  // 0001
                4 - 1 * 2,  // 0010
                4 - 2 * 2,  // 0011
                4 - 1 * 2,  // 0100
                4 - 2 * 2,  // 0101
                4 - 2 * 2,  // 0110
                4 - 3 * 2,  // 0111
                4 - 1 * 2,  // 1000
                4 - 2 * 2,  // 1001
                4 - 2 * 2,  // 1010
                4 - 3 * 2,  // 1011
                4 - 2 * 2,  // 1100
                4 - 3 * 2,  // 1101
                4 - 3 * 2,  // 1110
                4 - 4 * 2   // 1111
            };

            public QuestionInfo(XmlElement question)
            {
                this.itemScore = int.Parse(question.GetAttribute("score")) / question.SelectNodes("item").Count;

                foreach (XmlElement item in question.SelectNodes("item"))
                {
                    this.itemBits = this.itemBits << 1;
                    if (item.GetAttribute("correct") == "true") this.itemBits = this.itemBits | 0x0001;
                }

                Trace.WriteLine(this.itemBits);
            }

            public int GetScore(XmlElement question)
            {
                int answerBits = 0x0000;
                foreach (XmlElement item in question.ChildNodes)
                {
                    answerBits = answerBits << 1;
                    if (item.GetAttribute("checked") == "true") answerBits = answerBits | 0x0001;
                }

                if (answerBits == 0x0000) return 0;

                return this.correctItemCountTable[this.itemBits ^ answerBits] * this.itemScore;
            }
        }

        private List<QuestionInfo> Questions = new List<QuestionInfo>();

        public XorQuizHelper(XmlDocument quizDoc)
            : base(quizDoc)
        {
            foreach (XmlElement question in quizDoc.SelectNodes("/quiz/question"))
            {
                this.Questions.Add(new QuestionInfo(question));
            }
        }

        public override int ComputeScore(XmlDocument paperDoc)
        {
            int totalScore = 0;


            int questionPos = 0;
            foreach (XmlElement question in paperDoc.SelectNodes("/quiz/question"))
            {
                totalScore += this.Questions[questionPos++].GetScore(question);
            }

            return Math.Max(0, totalScore);
        }

    }
}