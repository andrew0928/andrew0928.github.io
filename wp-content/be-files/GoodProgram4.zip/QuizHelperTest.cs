﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using NUnitLite.Framework;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml;

namespace GoodProgram4

{
    /// <summary>
    /// Summary description for QuizHelperTest
    /// </summary>
    [TestFixture]
    public class QuizHelperTest
    {
        [Test]
        [DisplayName("答案完全跟標準答案一樣, 應該得到滿分")]
        public void PerfectPaperTest()
        {
            QuizHelper qh = QuizHelper.Create(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/quiz.xml"));
            Assert.AreEqual(
                100,
                qh.ComputeScore(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-perfect.xml")));
        }

        [Test]
        [DisplayName("繳交空白答案卷, 應該得到 0 分")]
        public void ZeroPaperTest()
        {
            QuizHelper qh = QuizHelper.Create(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/quiz.xml"));
            Assert.AreEqual(
                0,
                qh.ComputeScore(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-zero.xml")));
        }

        [Test]
        [DisplayName("完全沒作答的題目視為放棄, 不倒扣")]
        public void Normal1_PaperTest()
        {
            QuizHelper qh = QuizHelper.Create(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/quiz.xml"));

            Assert.AreEqual(
                20,
                qh.ComputeScore(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-normal1.xml")));
            Assert.AreEqual(
                40,
                qh.ComputeScore(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-normal2.xml")));
            Assert.AreEqual(
                40,
                qh.ComputeScore(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-normal3.xml")));
        }


        [Test]
        [DisplayName("答錯倒扣到 0 分為止")]
        public void Native_PaperTest()
        {
            QuizHelper qh = QuizHelper.Create(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/quiz.xml"));
            Assert.AreEqual(
                0,
                qh.ComputeScore(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-native.xml")));
        }

        [Test]
        [DisplayName("在指定時間內要能改完所有的答案卷")]
        public void PerformanceTest()
        {
            QuizHelper qh = QuizHelper.Create(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/quiz.xml"));
            Stopwatch timer = new Stopwatch();

            timer.Start();
            for (int count = 0; count < 1000; count++)
            {
                Assert.AreEqual(
                    100,
                    qh.ComputeScore(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-perfect.xml", false)));
                Assert.AreEqual(
                   0,
                   qh.ComputeScore(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-zero.xml", false)));
                Assert.AreEqual(
                    20,
                    qh.ComputeScore(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-normal1.xml", false)));
                Assert.AreEqual(
                    40,
                    qh.ComputeScore(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-normal2.xml", false)));
                Assert.AreEqual(
                    40,
                    qh.ComputeScore(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-normal3.xml", false)));
                Assert.AreEqual(
                    0,
                    qh.ComputeScore(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-native.xml", false)));
            }
            timer.Stop();

            Trace.WriteLine(
                string.Format("改完6000份考卷花了 {0} msec.", timer.ElapsedMilliseconds),
                "UnitTestMessage");

            Assert.True(1500 > timer.ElapsedMilliseconds);
        }

        [Test]
        [DisplayName("自動產生所有組合的答案券, 比對兩種演算法算出的成積")]
        public void OverAllTest()
        {
            QuizHelper qh1 = new BasicQuizHelper(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/quiz.xml"));
            QuizHelper qh2 = new XorQuizHelper(CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/quiz.xml"));

            XmlDocument paperDoc = CommonLibrary.Instance.GetCachedXmlDocument("~/WcmsModules/SampleCodes/TDD_Quiz/paper-perfect.xml");

            XmlNodeList items = paperDoc.SelectNodes("/quiz/question/item");
            for (int seed = 0; seed < 4096; seed++)
            {
                for (int itemPos = 0; itemPos < 12; itemPos++)
                {
                    (items[itemPos] as XmlElement).SetAttribute("checked", ((seed & (0x0001 << itemPos)) == 0) ? ("false") : ("true"));
                }

                Assert.AreEqual(qh1.ComputeScore(paperDoc), qh2.ComputeScore(paperDoc));
            }

        }
    }
}