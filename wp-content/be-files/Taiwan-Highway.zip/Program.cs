﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace ConsoleApplication12
{
    class Program
    {
        static void Main(string[] args)
        {
            Map highway = new Map();

            double cost = 0;
            foreach (string name in highway.FindBestPath("機場端", "基金", out cost))
            {
                Console.WriteLine("Node: {0}", name);
            }
            Console.WriteLine("Total Cost: {0}", cost);
        }
    }
}
