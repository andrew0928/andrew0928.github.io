﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication12
{
    public class Link
    {
        public double Distance = 0D;
        public Node FromNode = null;
        public Node ToNode = null;
        public RoadNameEnum Road;

        public Link(Node from, Node to, double distance, RoadNameEnum road)
        {
            this.FromNode = from;
            this.ToNode = to;
            this.Distance = distance;
            this.Road = road;
        }

        public string GetOtherNodeName(string name)
        {
            if (this.FromNode.Name == name)
            {
                return this.ToNode.Name;
            }
            else if (this.ToNode.Name == name)
            {
                return this.FromNode.Name;
            }
            else
            {
                throw new ArgumentException();
            }
        }

        public enum RoadNameEnum
        {
            Highway1,
            Highway2,
            Highway3
        }
    }
}
