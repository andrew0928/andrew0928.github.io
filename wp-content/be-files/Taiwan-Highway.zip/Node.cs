﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication12
{
    public class Node
    {
        public string Name = null;
        public int TollFee = 0;
        public List<Link> Links = new List<Link>();

        public Node(string name, int tollFee)
        {
            this.Name = name;
            this.TollFee = tollFee;
        }
    }
}
