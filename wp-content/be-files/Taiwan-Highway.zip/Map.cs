﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication12
{
    public class Map
    {
        private Dictionary<string, Node> _nodes = new Dictionary<string, Node>();


        public Map()
        {
            //
            //  construct / load map data
            //
            this.AddNode("基金", 0);
            this.AddNode("七堵收費站", 40);
            this.AddNode("汐止系統", 0);
            this.AddNode("樹林收費站", 40);
            this.AddNode("鶯歌系統", 0);
            this.AddNode("龍潭收費站", 40);
            this.AddNode("新竹系統", 0);


            this.AddNode("基龍端", 0);
            this.AddNode("汐止收費站", 40);
            this.AddNode("泰山收費站", 40);
            this.AddNode("機場系統", 0);
            this.AddNode("楊梅收費站", 40);
            this.AddNode("新竹", 0);

            this.AddNode("機場端", 0);

            this.AddLink("基金", "七堵收費站", 4.9-0, Link.RoadNameEnum.Highway3);
            this.AddLink("七堵收費站", "汐止系統", 10.9-4.9, Link.RoadNameEnum.Highway3);
            this.AddLink("汐止系統", "樹林收費站", 46.6-10.9, Link.RoadNameEnum.Highway3);
            this.AddLink("樹林收費站", "鶯歌系統",54.4-46.6, Link.RoadNameEnum.Highway3);
            this.AddLink("鶯歌系統", "龍潭收費站", 72.3-54.4, Link.RoadNameEnum.Highway3);
            this.AddLink("龍潭收費站", "新竹系統", 100.8-72.3, Link.RoadNameEnum.Highway3);

            this.AddLink("基龍端", "汐止收費站", 9.4, Link.RoadNameEnum.Highway1);
            this.AddLink("汐止收費站", "汐止系統", 10.9 - 9.4, Link.RoadNameEnum.Highway1);
            this.AddLink("汐止系統", "泰山收費站", 35.3-11.5, Link.RoadNameEnum.Highway1);
            this.AddLink("泰山收費站", "機場系統", 52.5-35.3, Link.RoadNameEnum.Highway1);
            this.AddLink("機場系統", "楊梅收費站", 71.4-52.5, Link.RoadNameEnum.Highway1);
            this.AddLink("楊梅收費站", "新竹", 95.4-71.4, Link.RoadNameEnum.Highway1);
            this.AddLink("新竹", "新竹系統", 99.4-95.4, Link.RoadNameEnum.Highway1);

            this.AddLink("機場端", "機場系統", 8.6, Link.RoadNameEnum.Highway2);
            this.AddLink("機場系統", "鶯歌系統", 20.4-8.6, Link.RoadNameEnum.Highway2);
        }

        private void AddNode(string name, int tollFee)
        {
            Node n = new Node(name, tollFee);
            this._nodes.Add(name, n);
        }


        private void AddLink(string n1, string n2, double distance, Link.RoadNameEnum road)
        {
            Node node1 = this._nodes[n1];
            Node node2 = this._nodes[n2];
            Link link = new Link(this._nodes[n1], this._nodes[n2], distance, road);
            node1.Links.Add(link);
            node2.Links.Add(link);
        }





        private double _cost = 0;
        private string[] _best_path = null;

        private Stack<string> _path = null;//new Stack<string>();
        private void Search(string startName, string endName, double current_cost)
        {
            this._path.Push(startName);

            if (startName == endName)
            {
                if (this._cost == 0 || current_cost < this._cost)
                {
                    this._cost = current_cost;
                    this._best_path = this._path.ToArray();
                }


                this._path.Pop();
                return;
            }

            foreach (Link way in this._nodes[startName].Links)
            {
                string next = way.GetOtherNodeName(startName);
                if (this._path.Contains(next) == false)
                {
                    this.Search(
                        next,
                        endName,
                        current_cost + this._nodes[next].TollFee + way.Distance * 2);
                }
            }
            this._path.Pop();
        }

        public string[] FindBestPath(string startName, string endName, out double cost)
        {
            try
            {
                this._cost = 0;
                this._path = new Stack<string>();
                this.Search(startName, endName, 0);

                cost = this._cost;
                return this._best_path;
            }
            finally
            {
                this._cost = 0;
                this._path = null;
            }
        }








        public Link FindLink(string name1, string name2)
        {
            foreach (Link way in this._nodes[name1].Links)
            {
                if (way.GetOtherNodeName(name1) == name2) return way;
            }

            return null;
        }




















    }
}
