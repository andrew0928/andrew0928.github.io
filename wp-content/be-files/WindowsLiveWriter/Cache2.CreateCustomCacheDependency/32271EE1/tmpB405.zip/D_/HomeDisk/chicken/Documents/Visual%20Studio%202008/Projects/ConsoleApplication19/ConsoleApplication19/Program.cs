﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Caching;
using System.Threading;

namespace ConsoleApplication19
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] urls = new string[] {
                "http://columns.chicken-house.net/",
                "http://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4244658577287067&output=html&h=15&slotname=6711360105&w=728&lmt=1261207703&flash=10.0.32.18&url=http%3A%2F%2Fcolumns.chicken-house.net%2F&dt=1261207703522&correlator=1261207703523&frm=0&ga_vid=442234322.1261207704&ga_sid=1261207704&ga_hid=750282505&ga_fc=0&u_tz=480&u_his=5&u_java=1&u_h=1050&u_w=1680&u_ah=1020&u_aw=1680&u_cd=32&u_nplug=0&u_nmime=0&biw=1003&bih=822&ref=http%3A%2F%2Fcolumns.chicken-house.net%2Flogin.aspx&fu=0&ifi=1&dtd=95&xpc=x5WLAUbdb3&p=http%3A//columns.chicken-house.net",
                "http://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4244658577287067&output=html&h=90&slotname=8309178164&w=728&lmt=1261207703&flash=10.0.32.18&url=http%3A%2F%2Fcolumns.chicken-house.net%2F&dt=1261207703624&prev_slotnames=6711360105&correlator=1261207703523&frm=0&ga_vid=442234322.1261207704&ga_sid=1261207704&ga_hid=750282505&ga_fc=0&u_tz=480&u_his=5&u_java=1&u_h=1050&u_w=1680&u_ah=1020&u_aw=1680&u_cd=32&u_nplug=0&u_nmime=0&biw=1003&bih=822&ref=http%3A%2F%2Fcolumns.chicken-house.net%2Flogin.aspx&fu=0&ifi=2&dtd=89&xpc=txDnZFei1H&p=http%3A//columns.chicken-house.net",
                "http://funp.com/tools/images/post_03.gif",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe8a8ade8a888e6a188e4be8b-e6b885e999a4Cachee789a9e4bbb6-1-e5958fe9a18ce88887e4bd9ce6b395.aspx&s=1",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe7b582e696bce7aa81e7a0b4e596aee697a5-100KM-e4ba86-D-(e58fb0e58c97-3c-3e-e5a4a7e6baaa).aspx&s=1",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe8a8ade8a888e6a188e4be8b-6-e68abde5838fe58c96.aspx&s=1",
                "http://www.hemidemi.com/scriptlet/bookmark/106/106c330698857d3f9a12d7d0ac0e9e42/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe7b582e696bce7aa81e7a0b4e596aee697a5-100KM-e4ba86-D-(e58fb0e58c97-3c-3e-e5a4a7e6baaa).aspx&t=HEMiDEMi",
                "http://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4244658577287067&output=html&h=250&slotname=5318625475&w=250&lmt=1261207704&flash=10.0.32.18&url=http%3A%2F%2Fcolumns.chicken-house.net%2F&dt=1261207704137&prev_slotnames=6711360105%2C8309178164%2C6711360105%2C8309178164&correlator=1261207703523&frm=0&ga_vid=442234322.1261207704&ga_sid=1261207704&ga_hid=750282505&ga_fc=0&u_tz=480&u_his=5&u_java=1&u_h=1050&u_w=1680&u_ah=1020&u_aw=1680&u_cd=32&u_nplug=0&u_nmime=0&biw=986&bih=822&ref=http%3A%2F%2Fcolumns.chicken-house.net%2Flogin.aspx&fu=0&ifi=5&dtd=8&xpc=S49LGpFmZc&p=http%3A//columns.chicken-house.net",
                "http://urs.microsoft.com:443",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe8a8ade8a888e6a188e4be8b-e7949fe591bde9818ae688b2-5-e4b8ade5a0b4e4bc91e681af.aspx&s=1",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe99bbbe885a6e69982e99098e8b68ae4be86e8b68ae685a2.aspx&s=1",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe8a8ade8a888e6a188e4be8b-e7949fe591bde9818ae688b23-e69982e5ba8fe79a84e68ea7e588b6.aspx&s=1",
                "http://www.hemidemi.com/scriptlet/bookmark/bac/bac6753a1a75f1fea80c3b2d53f0a818/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe99bbbe885a6e69982e99098e8b68ae4be86e8b68ae685a2.aspx&t=HEMiDEMi",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe8a8ade8a888e6a188e4be8b-e7949fe591bde9818ae688b2-4-e69c89e69588e78e87e79a84e4bdbfe794a8e59fb7e8a18ce7b792.aspx&s=1",
                "http://www.hemidemi.com/scriptlet/bookmark/afd/afd5042786ed8675c77ddd20fe02b6ad/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe8a8ade8a888e6a188e4be8b-e7949fe591bde9818ae688b23-e69982e5ba8fe79a84e68ea7e588b6.aspx&t=HEMiDEMi",
                "http://www.hemidemi.com/scriptlet/bookmark/bd9/bd93517930366bef519f01179b47c117/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe8a8ade8a888e6a188e4be8b-e7949fe591bde9818ae688b2-4-e69c89e69588e78e87e79a84e4bdbfe794a8e59fb7e8a18ce7b792.aspx&t=HEMiDEMi",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe8a8ade8a888e6a188e4be8b-e7949fe591bde9818ae688b21-e5898de8a880.aspx&s=1",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fHVRemote-(Hyper-V-Remote-Management-Configuration-Utility).aspx&s=1",
                "http://www.hemidemi.com/scriptlet/bookmark/44e/44e080824a0776f900851f90a11b4350/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe8a8ade8a888e6a188e4be8b-e7949fe591bde9818ae688b22-OOPe78988e79a84e7af84e4be8be7a88be5bc8f.aspx&t=HEMiDEMi",
                "http://www.hemidemi.com/scriptlet/bookmark/e07/e07307b7d9d716a5107b7f27410dd73b/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe8a8ade8a888e6a188e4be8b-e6b885e999a4Cachee789a9e4bbb6-1-e5958fe9a18ce88887e4bd9ce6b395.aspx&t=HEMiDEMi",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fJPEG-XR-(e5b0b1e698af-Microsoft-HD-Photo-e595a6)-e5b7b2e7b693e698af-ISO-e6ada3e5bc8fe6a899e6ba96e4ba86.aspx&s=1",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2f555555-e4babae6aca1e7b480e5bfb5!.aspx&s=1",
                "http://urs.microsoft.com:443",
                "http://www.hemidemi.com/scriptlet/bookmark/97a/97aa7281938e1f3a9b9da7051aa97904/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2FJPEG-XR-(e5b0b1e698af-Microsoft-HD-Photo-e595a6)-e5b7b2e7b693e698af-ISO-e6ada3e5bc8fe6a899e6ba96e4ba86.aspx&t=HEMiDEMi",
                "http://www.hemidemi.com/scriptlet/bookmark/3a4/3a490ed18feecfc2e3da9890fac2322e/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2F555555-e4babae6aca1e7b480e5bfb5!.aspx&t=HEMiDEMi",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe68bbce4ba86!-80e585ace9878ce995b7e5be81-(e9979ce6b8a1-e9b6afe6ad8c).aspx&s=1",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe9979ce6b8a1e9a88ee596aee8bb8a.aspx&s=1",
                "http://www.hemidemi.com/scriptlet/bookmark/010/010e28c7bc178bd8056ceceb9513c77d/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe9979ce6b8a1e9a88ee596aee8bb8a.aspx&t=HEMiDEMi",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe5808be4babae6aa94e6a188-2b-e78988e69cace68ea7e588b6.aspx&s=1",
                "http://www.hemidemi.com/scriptlet/bookmark/828/828e975bc07ccae5477f2eac8e178cfd/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe5808be4babae6aa94e6a188-2b-e78988e69cace68ea7e588b6.aspx&t=HEMiDEMi",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fRUNPC-e7b2bee981b8e69687e7aba0-e9818be794a8ThreadPoole799bce68faeCPUe9818be7ae97e883bde58a9b.aspx&s=1",
                "http://www.hemidemi.com/scriptlet/bookmark/02a/02a20b26afce124cb1f5026a1554ba81/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2FRUNPC-e7b2bee981b8e69687e7aba0-e9818be794a8ThreadPoole799bce68faeCPUe9818be7ae97e883bde58a9b.aspx&t=HEMiDEMi",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fEF3-Entity-Inheritance.aspx&s=1",
                "http://www.hemidemi.com/scriptlet/bookmark/ce2/ce2730f23ee16285bc76b00f4434feb8/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2FEF2-Entity-Encapsulation.aspx&t=HEMiDEMi",
                "http://www.hemidemi.com/scriptlet/bookmark/df4/df42a18f4f417109ec562b3947b73ddb/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2FEF3-Entity-Inheritance.aspx&t=HEMiDEMi",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fEF1-e8a681e5adb8e5a5bd-Entity-Framework-e8ab8be58588e5adb8e5a5bd-OOP-e8b79f-C-.aspx&s=1",
                "http://www.hemidemi.com/scriptlet/bookmark/85c/85c2f11d1e27d040101f81523f106e8b/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe99ba3e6909ee79a84-Entity-Framework-e8b7a8e8b68a-Context-e79a84e69fa5e8a9a2.aspx&t=HEMiDEMi",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe99ba3e6909ee79a84-Entity-Framework-e8b7a8e8b68a-Context-e79a84e69fa5e8a9a2.aspx&s=1",
                "http://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4244658577287067&output=html&h=90&slotname=8309178164&w=728&lmt=1261207704&flash=10.0.32.18&url=http%3A%2F%2Fcolumns.chicken-house.net%2F&dt=1261207704033&prev_slotnames=6711360105%2C8309178164%2C6711360105&correlator=1261207703523&frm=0&ga_vid=442234322.1261207704&ga_sid=1261207704&ga_hid=750282505&ga_fc=0&u_tz=480&u_his=5&u_java=1&u_h=1050&u_w=1680&u_ah=1020&u_aw=1680&u_cd=32&u_nplug=0&u_nmime=0&biw=986&bih=822&ref=http%3A%2F%2Fcolumns.chicken-house.net%2Flogin.aspx&fu=0&ifi=4&dtd=89&xpc=riVrvW8CyV&p=http%3A//columns.chicken-house.net",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fe8a8ade8a888e6a188e4be8b-e7949fe591bde9818ae688b22-OOPe78988e79a84e7af84e4be8be7a88be5bc8f.aspx&s=1",
                "http://www.hemidemi.com/scriptlet/bookmark/229/22913a50ec403ceae1d5d2eaa46534ef/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe68bbce4ba86!-80e585ace9878ce995b7e5be81-(e9979ce6b8a1-e9b6afe6ad8c).aspx&t=HEMiDEMi",
                "http://www.hemidemi.com/scriptlet/bookmark/e60/e60e033154ab1131a8d52eeae2527e9b/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe8a8ade8a888e6a188e4be8b-e7949fe591bde9818ae688b21-e5898de8a880.aspx&t=HEMiDEMi",
                "http://www.hemidemi.com/scriptlet/bookmark/04b/04b2c30d56942abf1aaa4804f0600b00/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe8a8ade8a888e6a188e4be8b-e7949fe591bde9818ae688b2-5-e4b8ade5a0b4e4bc91e681af.aspx&t=HEMiDEMi",
                "http://www.hemidemi.com/scriptlet/bookmark/9e3/9e346ce79e3b988fd021ad5101680a17/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2FEF1-e8a681e5adb8e5a5bd-Entity-Framework-e8ab8be58588e5adb8e5a5bd-OOP-e8b79f-C-.aspx&t=HEMiDEMi",
                "http://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4244658577287067&output=html&h=15&slotname=6711360105&w=728&lmt=1261207703&flash=10.0.32.18&url=http%3A%2F%2Fcolumns.chicken-house.net%2F&dt=1261207703935&prev_slotnames=6711360105%2C8309178164&correlator=1261207703523&frm=0&ga_vid=442234322.1261207704&ga_sid=1261207704&ga_hid=750282505&ga_fc=0&u_tz=480&u_his=5&u_java=1&u_h=1050&u_w=1680&u_ah=1020&u_aw=1680&u_cd=32&u_nplug=0&u_nmime=0&biw=986&bih=822&ref=http%3A%2F%2Fcolumns.chicken-house.net%2Flogin.aspx&fu=0&ifi=3&dtd=90&xpc=iVgD1fSxB6&p=http%3A//columns.chicken-house.net",
                "http://www.hemidemi.com/scriptlet/bookmark/5ca/5cab0cdf4960a4cd8a16da4dce7b24e5/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2Fe8a8ade8a888e6a188e4be8b-6-e68abde5838fe58c96.aspx&t=HEMiDEMi",
                "http://funp.com/tools/buttoniframe.php?url=http%3a%2f%2fcolumns.chicken-house.net%2fpost%2fEF2-Entity-Encapsulation.aspx&s=1",
                "http://www.facebook.com/badge.php?id=1836073899&bid=531&key=1687971105&format=png&z=513366494",
                "http://www.hemidemi.com/scriptlet/bookmark/619/619ca834cb2f0e706b550749b1731265/button1.html?s=button1&bg=white&u=http%3A%2F%2Fcolumns.chicken-house.net%2Fpost%2FHVRemote-(Hyper-V-Remote-Management-Configuration-Utility).aspx&t=HEMiDEMi"
            };


            foreach (string url in urls)
            {
                DownloadData(new Uri(url));
            }

            //InfoFlag = true;
            Console.ReadLine();
            TaggingCacheDependency.DependencyDispose("funp.com");
            Console.ReadLine();
        }

        //private static bool InfoFlag = false;
        private static void Info(string key, object value, CacheItemRemovedReason reason)
        {
            //if (InfoFlag == true) 
                Console.WriteLine("Remove: {0}", key);
        }

        private static byte[] DownloadData(Uri sourceURL)
        {
            byte[] buffer = (byte[])HttpRuntime.Cache[sourceURL.ToString()];

            if (buffer == null)
            {
                // data not in cache. download from web site directly.
                // fake data. just for demo
                buffer = Guid.NewGuid().ToByteArray();
                HttpRuntime.Cache.Add(
                    sourceURL.ToString(),
                    buffer,
                    new TaggingCacheDependency(sourceURL.Host, sourceURL.Scheme),
                    Cache.NoAbsoluteExpiration,
                    TimeSpan.FromSeconds(600),
                    CacheItemPriority.NotRemovable,
                    Info);
            }

            return buffer;
        }
    }


    public class TaggingCacheDependency : CacheDependency, IDisposable
    {
        private static Dictionary<string, List<TaggingCacheDependency>> _lists = new Dictionary<string, List<TaggingCacheDependency>>();

        public TaggingCacheDependency(params string[] tags)
        {
            foreach (string tag in tags)
            {
                if (_lists.ContainsKey(tag) == false)
                {
                    _lists.Add(tag, new List<TaggingCacheDependency>());
                }
                _lists[tag].Add(this);
            }
            this.SetUtcLastModified(DateTime.MinValue);
            this.FinishInit();
        }

        public static void DependencyDispose(string tag)
        {
            if (_lists.ContainsKey(tag) == true)
            {
                foreach (TaggingCacheDependency tcd in _lists[tag])
                {
                    tcd.NotifyDependencyChanged(null, EventArgs.Empty);
                }
                _lists[tag].Clear();
                _lists.Remove(tag);
            }
        }



        #region IDisposable Members

        void IDisposable.Dispose()
        {
            //this.DependencyDispose();
            //this.NotifyDependencyChanged(this, EventArgs.Empty);
        }

        #endregion
    }
}
