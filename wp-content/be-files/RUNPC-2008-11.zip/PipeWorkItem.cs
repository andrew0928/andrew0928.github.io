﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ICSharpCode.SharpZipLib.Zip;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;

namespace Pipeline
{
    public abstract class PipeWorkItem
    {
        public abstract void Stage1();
        public abstract void Stage2();
    }

    public class MakeThumbPipeWorkItem : PipeWorkItem
    {
        public ZipOutputStream zipos = null;
        public string SourceImageFile = null;


        private string temp = null;

        public override void Stage1()
        {
            //第一階段: 縮圖
            this.temp = Path.ChangeExtension(this.SourceImageFile, ".temp");
            if (File.Exists(this.temp) == true) File.Delete(this.temp);
            MakeThumb(this.SourceImageFile, this.temp, 1600, 1600);

            Console.WriteLine("Make Thumb: {0}", Path.GetFileName(this.temp));
        }

        public override void Stage2()
        {
            //第二階段: 壓縮
            ZipEntry ze = new ZipEntry(Path.GetFileName(Path.ChangeExtension(this.SourceImageFile, ".PNG")));
            zipos.SetLevel(9);
            zipos.PutNextEntry(ze);

            byte[] buffer = File.ReadAllBytes(this.temp);
            zipos.Write(
                buffer,
                0,
                buffer.Length);

            Console.WriteLine("Compress: {0}", Path.GetFileName(this.temp));
            File.Delete(this.temp);
            this.temp = null;
        }

        private static void MakeThumb(string srcfile, string trgfile, int maxWidth, int maxHeight)
        {
            Image srcBitmap = Image.FromFile(srcfile);

            double ratioX = 1D * srcBitmap.Size.Width / maxWidth;
            double ratioY = 1D * srcBitmap.Size.Height / maxHeight;

            Image trgBitmap = new Bitmap(
                (int)(srcBitmap.Size.Width / Math.Max(ratioX, ratioY)),
                (int)(srcBitmap.Size.Height / Math.Max(ratioX, ratioY)));

            Graphics dc = Graphics.FromImage(trgBitmap);
            dc.DrawImage(
                srcBitmap,
                0, 0,
                trgBitmap.Size.Width, trgBitmap.Size.Height);
            dc.Dispose();

            FileStream trgfs = File.OpenWrite(trgfile);
            trgBitmap.Save(trgfs, ImageFormat.Png);
            trgfs.Close();

            srcBitmap.Dispose();
            trgBitmap.Dispose();
        }
    }

}
