﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace Pipeline
{
    public class PipeWorkRunner
    {
        private bool _is_start = false;

        public void AddWorkItem(PipeWorkItem item)
        {
            if (this._is_start == true) throw new InvalidOperationException();

            this._stage1_queue.Enqueue(item);
        }


        public void NonPipelineStart()
        {
            while (this._stage1_queue.Count > 0)
            {
                PipeWorkItem item = this._stage1_queue.Dequeue();
                item.Stage1();
                item.Stage2();
            }
        }

        public void Start()
        {
            //啟動生產線的執行緒
            this._is_start = true;

            //階段1: 準備三個執行緒
            this._stage1_thread.Add(new Thread(this.Stage1Runner));
            this._stage1_thread.Add(new Thread(this.Stage1Runner));
            this._stage1_thread.Add(new Thread(this.Stage1Runner));

            this._stage2_thread.Add(new Thread(this.Stage2Runner));

            foreach (Thread t in this._stage1_thread) t.Start();
            foreach (Thread t in this._stage2_thread) t.Start();

            foreach (Thread t in this._stage1_thread) t.Join();
            foreach (Thread t in this._stage2_thread) t.Join();
        }


        private List<Thread> _stage1_thread = new List<Thread>();
        private List<Thread> _stage2_thread = new List<Thread>();
        

        private Queue<PipeWorkItem> _stage1_queue = new Queue<PipeWorkItem>();
        private Queue<PipeWorkItem> _stage2_queue = new Queue<PipeWorkItem>();

        //private ManualResetEvent _notify_stage1 = new ManualResetEvent(false);
        private ManualResetEvent _notify_stage2 = new ManualResetEvent(false);

        private void Stage1Runner()
        {
            PipeWorkItem pwi = null;
            while (true)
            {
                pwi = null;

                lock (this._stage1_queue)
                {
                    if (this._stage1_queue.Count > 0) pwi = this._stage1_queue.Dequeue();
                }

                if (pwi == null) break;

                pwi.Stage1();

                //lock (this._stage2_queue)
                {
                    this._stage2_queue.Enqueue(pwi);
                }

                this._notify_stage2.Set();
            }
        }

        private void Stage2Runner()
        {
            Stopwatch idle_timer = new Stopwatch();
            while (true)
            {
                while (this._stage2_queue.Count > 0)
                {
                    PipeWorkItem pwi = this._stage2_queue.Dequeue();
                    pwi.Stage2();
                    Console.WriteLine("Queued items in stage 2: {0}", this._stage2_queue.Count);
                }

                //
                //  檢查 stage 1 所有的 thread 是否已經全部結束?
                //
                {
                    bool _isAllStopped = true;
                    foreach (Thread t1 in this._stage1_thread)
                    {
                        if (t1.IsAlive == true) _isAllStopped = false;
                    }
                    if (_isAllStopped == true) break;
                }

                idle_timer.Reset();
                idle_timer.Start();
                this._notify_stage2.WaitOne();
                this._notify_stage2.Reset();
                Console.WriteLine("Stage 2: Idle {0} msec", idle_timer.ElapsedMilliseconds);
            }
        }
    }
}
