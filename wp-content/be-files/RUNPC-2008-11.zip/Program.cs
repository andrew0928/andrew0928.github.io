﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ICSharpCode.SharpZipLib.Zip;
using System.IO;
using System.Diagnostics;

namespace Pipeline
{
    class Program
    {
        static void Main(string[] args)
        {
            PipeWorkRunner runner = new PipeWorkRunner();
            string zipfile = @"D:\TempDisk\IMAGES\result.zip";

            if (File.Exists(zipfile) == true) File.Delete(zipfile);
            FileStream zos = File.OpenWrite(zipfile);
            ZipOutputStream zipos = new ZipOutputStream(zos);


            foreach (string imgfile in Directory.GetFiles(@"D:\TempDisk\IMAGES", "*.jpg"))
            {
                MakeThumbPipeWorkItem pi = new MakeThumbPipeWorkItem();

                pi.SourceImageFile = imgfile;
                pi.zipos = zipos;

                runner.AddWorkItem(pi);
            }

            Stopwatch timer = new Stopwatch();
            timer.Start();
            
            // 不啟用生產線，直接執行
            runner.NonPipelineStart();

            // 啟用生產線模式
            //runner.Start();

            Console.WriteLine("Total Time: {0} msec", timer.ElapsedMilliseconds);
            zipos.Close();
        }
    }
}
